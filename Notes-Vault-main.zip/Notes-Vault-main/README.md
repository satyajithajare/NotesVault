# Notes-Vault
The project involves building a robust Notes Vault application using React and Spring Boot. This secure platform enables users to create, manage, and share notes seamlessly. Additionally, integrated speech-to-text functionality for effortless note creation. To store notes MySQL database is used. 
